# DIY Flight Simulator Controller

An Arduino Pro Micro-based USB flight-simulator controller with four analog controls and five digital buttons. This repository contains the firmware, wiring references, and the supplied 3D-printable STL parts.

> **Project status:** Files are organized from the supplied design and firmware. The sketch has not been hardware-tested as part of preparing this repository. Verify every connection and test the controls in your operating system's game-controller panel before using the controller in a simulator.

## Features

- **Roll:** potentiometer on A6 (also identified as D4 on the supplied Pro Micro pin reference)
- **Pitch:** potentiometer on A3
- **Throttle:** potentiometer on A0
- **Mixture:** potentiometer on A1, exposed to the computer as the joystick **Brake** axis
- **Buttons:** one activation pushbutton and four toggle switches (five joystick buttons total)
- **Enclosure:** three supplied STL files in `3D-Models/`

## Hardware

- Arduino Pro Micro / ATmega32U4 board (use a board variant compatible with the 5 V wiring shown in the references)
- 4 × potentiometers (typically 10 kΩ; confirm your chosen parts)
- 4 × 3-terminal toggle switches
- 1 × momentary pushbutton
- Jumper wires, hookup wire, and a USB cable
- 3D printer and suitable filament for the enclosure parts

## Wiring

### Potentiometers

Each potentiometer has three terminals:

| Control | Middle terminal (wiper) |
|---|---:|
| Throttle | A0 |
| Mixture | A1 |
| Roll | A6 (D4 on the supplied pin reference) |
| Pitch | A3 |

For each potentiometer, connect one outer terminal to **VCC (5 V)**, the middle terminal to its assigned analog pin, and the other outer terminal to **GND**. Reversing the two outer terminals reverses that control's direction.

### Buttons and toggle switches

| Control | Pro Micro pin | USB joystick button |
|---|---:|---:|
| Activation pushbutton | D2 | Button 1 |
| Toggle switch 1 | D3 | Button 2 |
| Toggle switch 2 | D5 | Button 3 |
| Toggle switch 3 | D7 | Button 4 |
| Toggle switch 4 | D8 | Button 5 |

For each toggle switch, connect the middle/common (COM) terminal to **GND**, one outer terminal to its assigned digital pin, and leave the other outer terminal disconnected. The firmware uses `INPUT_PULLUP`, so the switch reads active when it connects the input to ground. Connect the activation pushbutton between D2 and GND.

All components share the board's GND. Do not connect a switch's unused outer terminal.

See `Images/` for the original wiring and pin-reference screenshots.

## Firmware setup

1. Install the Arduino IDE.
2. Install/select an Arduino Pro Micro-compatible ATmega32U4 board package.
3. Install the **Joystick** library that provides `Joystick.h` (the Arduino Joystick library by Matthew Heironimus).
4. Open `Firmware/flight_simulator_controller.ino`.
5. Select the correct Pro Micro board, processor/clock variant, and serial port.
6. Upload the sketch and reconnect the board if required by its bootloader.
7. Open your operating system's game-controller settings and check all four axes and five buttons.

The sketch configures X, Y, Throttle, and Brake axes. It maps roll to X, pitch to Y, throttle to Throttle, and mixture to Brake. The loop sends updated joystick state every 5 ms.

## 3D-print files

| File | Supplied filename | Bounding dimensions from STL (X × Y × Z) |
|---|---|---:|
| Base | `flightsimbase.stl` | 156 × 120 × 73.68 mm |
| Lid | `flightsimlid.stl` | 130 × 127.70 × 14 mm |
| Cover | `flightsimcover.stl` | 19 × 29.5 × 24 mm |

Dimensions are the mesh bounding boxes, not guaranteed fit tolerances. Import the STLs into your slicer, inspect orientation and scale, and test-fit parts before final assembly. The base STL was reported as non-watertight by a mesh inspection; check/repair it in your slicer or CAD tool if it causes slicing issues.

No print settings, material, infill, supports, or fastener specifications were included with the supplied files; choose and validate these for your printer and design.

## Repository layout

```text
DIY-Flight-Simulator-Controller/
├── Firmware/
│   └── flight_simulator_controller.ino
├── 3D-Models/
│   ├── flightsimbase.stl
│   ├── flightsimcover.stl
│   └── flightsimlid.stl
├── Documentation/
│   └── WIRING.md
├── Images/
│   ├── pin-reference.png
│   ├── potentiometer-wiring-reference.png
│   └── switch-and-button-wiring-reference.png
├── .gitignore
├── LICENSE
└── README.md
```

## Contributing

Issues and pull requests are welcome. When proposing hardware or firmware changes, include the board variant, wiring changes, library versions, and test results.

## License

The repository includes an MIT license. Before publishing, confirm that you have the rights to license all included firmware, images, and 3D models under it; the license file does not establish ownership of third-party material.
